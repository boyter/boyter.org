<?php
interface iranker {
	public function rankDocuments($document,$document2);
}
?>