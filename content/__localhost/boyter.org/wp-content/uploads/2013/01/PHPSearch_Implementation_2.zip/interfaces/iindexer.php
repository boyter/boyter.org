<?php
interface iindexer {
	public function index(array $documents);
}
?>