<?php
$fp = fopen('data.txt','w');

for($i=0;$i<10;$i++) {
  $bindata = pack('i',intval($i));
  fwrite($fp,$bindata);
}
fclose($fp);

$fp = fopen('data.txt','r');
for($i=0;$i<10;$i++) {
  $bindata = fread($fp,4);
  print_r(unpack('i',$bindata));
}
fclose($fp);
?>

<?php
define('BIT_1', 1);     // 0001
define('BIT_2', 2);     // 0010
define('BIT_3', 4);     // 0100
define('BIT_4', 8);     // 1000
define('BIT_5', 16);    // 0001 0000
define('BIT_6', 32);    // 0010 0000
define('BIT_7', 64);    // 0100 0000
define('BIT_8', 128);   // 1000 0000
define('BIT_9', 256);   // 0001 0000 0000
define('BIT_10', 512);  // 0010 0000 0000
define('BIT_11', 1024); // 0100 0000 0000
define('BIT_12', 2048); // 1000 0000 0000
define('BIT_13', 4096);
define('BIT_14', 8192);
define('BIT_15', 16384);
define('BIT_16', 32768);
define('BIT_17', 65536);
define('BIT_18', 131072);
define('BIT_19', 262144);
define('BIT_20', 524288);
define('BIT_21', 1048576);
define('BIT_22', 2097152);
define('BIT_23', 4194304);
define('BIT_24', 8388608);
define('BIT_25', 16777216);
define('BIT_26', 33554432);
define('BIT_27', 67108864);
define('BIT_28', 134217728);
define('BIT_29', 268435456);
define('BIT_30', 536870912);
define('BIT_31', 1073741824);
define('BIT_32', 2147483648);

$signal = 0;
$signal ^= BIT_1;
$signal ^= BIT_11;
echo ($signal & BIT_1 ? 1: 0);
echo ($signal & BIT_2 ? 1: 0);
echo ($signal & BIT_11 ? 1: 0);
echo "|";
$signal ^= BIT_1;
echo ($signal & BIT_1 ? 1: 0);
echo ($signal & BIT_2 ? 1: 0);
echo ($signal & BIT_11 ? 1: 0);
?>