<?php
require_once(dirname(__FILE__) . '/simpletest/autorun.php');
require_once('singlefolderindex_test.php');
require_once('singlefolderdocumentstore_test.php');
require_once('naievesearch_test.php');
require_once('naieveindexer_test.php');
?>