<?php
interface isearch {
	public function dosearch($searchterms);
}
?>